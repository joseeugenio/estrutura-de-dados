#include <stdio.h>
#include <stdlib.h>

int main () {
  
  int S;
  int Q;
  int *sVector;
  int *qVector;

	         printf("Digite o tamanho da primeira sequência ordenada de inteiros:\n");
	     		 scanf("%d", &S);
	     		 sVector = malloc(S*sizeof(int));//espaço alocado para o array 'S'
	     		 
		     	for(int cont_S=0; cont_S<S ; cont_S++){
		     	  //laço para armazenar as variaveis no array 'S' a cada iteração
		     	  printf("\n (1)digite a %d ºiteração\n", cont_S+1);
		     		scanf("%d", &sVector[cont_S]);
		     	}
		     	 printf("fim do laço de armazenamento de variaveis do primeiro array\n\n");

     		printf("Digite o tamanho da segunda sequência ordenada de inteiros");
     		scanf("%d", &Q);
     		qVector = malloc(Q*sizeof(int));//espaço alocado para o array 'Q'

     		    for(int cont_Q=0 ; cont_Q<Q ; cont_Q++){
     		   //laço para armazenar as variaveis no array 'Q' a cada iteração
            printf("\n (2) digite a %d ºiteração\n", cont_Q+1);
		     		scanf("%d", &qVector[cont_Q]);
		     	}
		     	printf("\n fim do laço de armazenamento de variaveis do primeiro array\n\n");
            		
                    for(int i =0; i < S; i++)//laço de verificação de diferença
                    {                       
                        int diferente = 1; //'diferente' armazena 1 para verificar se o numero é diferente 
                     
                            for (int j=0 ; j<Q ; j++){
                                if(sVector[i]==qVector[j])//verifica se existe igualdade
                                {
                                    diferente=0;
                                    break;
                                }
                            }
                            if(diferente)
                            	{
                                    printf("%d", sVector[i]);
                                    if(i+1 != S) printf(" ");
                                }
                    }

	return 0;
}